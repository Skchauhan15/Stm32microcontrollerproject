/*
 * TFT_MENU.c
 *
 *
 *      Author:sumit kumar(skchauhan15101996@gmail.com)
 */
#include "TFT_MENU.h"
#include "stm32f1xx_hal.h"
#include "ST7735.h"
#include "fonts.h"
#include "GFX_FUNCTIONS.h"
#include "MAX6675.h"
#include "FLASH_PAGE_F1.h"
#include "main.h"
#include<stdio.h>

TIM_HandleTypeDef htim2;
// Menu buttons defines
int homemenu=0,page2menu=0,testmenu=0,page3menu=0,page4menu = 0,page5menu = 0;
int recipesettingpage=0,preheatingsettingpage=0,sleeptimerpage=0;
int portionpager1=0,portionpager2=0,portionpager3=0,portionpager4=0,portionpager5=0,p1;
int recipe1setting=0,recipe2setting=0,recipe3setting=0;
int heatbutton=0,autocookingbtn=0,manualbtn=0,settingbtn=0, rcounterbtn=0,recipe1=0,recipe2=0,recipe3=0,recipe4=0,recipe5=0;
int recipesetting=0,preheatingsetting=0,sleeptimer=0,settemp=0,manualstart=0;
int T=0,heatingvalue,tempreture=50;
// physical buttons defines
int downbutton=0, back=0, enter=0,limitup,limitdown,upbutton=0;
int portion1btn=0,portion2btn=0,portion3btn=0;
int portionpager11=0,portionpager111=0,portionpager112=0,portionpager12=0,portionpager121=0,portionpager122=0,portionpager13=0,portionpager131=0,portionpager132=0;
int portionpager21=0,portionpager211=0,portionpager212=0,portionpager22=0,portionpager221=0,portionpager222=0,portionpager23=0,portionpager231=0,portionpager232=0;
int portionpager31=0,portionpager311=0,portionpager312=0,portionpager32=0,portionpager321=0,portionpager322=0,portionpager33=0,portionpager331=0,portionpager332=0;
int portionpager41=0,portionpager411=0,portionpager412=0,portionpager42=0,portionpager421=0,portionpager422=0,portionpager43=0,portionpager431=0,portionpager432=0;
int portionpager51=0,portionpager511=0,portionpager512=0,portionpager52=0,portionpager521=0,portionpager522=0,portionpager53=0,portionpager531=0,portionpager532=0;
float  RxVal,RxVal1,RxVal2,RxVal3;//for time
char temp[20],t1_1[20],hv[20],tm[50],tem[20];
char tr[20]; //for tempreture
int tpr1_1=0,tpr1_2=0,tpr1_3=0,tpr2_1=0,tpr2_2=0,tpr2_3=0,tpr3_1=0,tpr3_2=0,tpr3_3=0;   //for tempreture
uint16_t time_value;
uint16_t escaped_time,escaped_time2,escaped_time3;
char tm[50];
int time,time1=0;
void P1Heat_Button_unselect (void)  //heater button unselected
{
	drawRoundRect(55, 89, 50, 27, 8, WHITE);
	fillRoundRect(55, 90, 50, 25, 8, RED);
	ST7735_WriteString(70, 93, "OK", Font_11x18, WHITE, RED);
	ST7735_WriteString(65, 77, "PRESS", Font_7x10, GREEN, BLACK);
	heatbutton = 0;
}
void P1Heat_Button_select (void)    //heater button selected
{
	drawRoundRect(79, 89, 50, 27, 8, RED);
	fillRoundRect(80, 90, 50, 25, 8, GREEN);
	ST7735_WriteString(88, 53, "OK", Font_11x18, BLACK, GREEN);
	ST7735_WriteString(38, 53, "PRESS", Font_11x18, BLACK, GREEN);
	heatbutton = 1;
}
void AUTOCOOKING_Button_unselect (void)
{
	fillRoundRect(10, 18, 140, 20, 8, RED);
	ST7735_WriteString(15, 19, "AUTOCOOKING", Font_11x18, WHITE, RED);
	autocookingbtn = 0;
}

void AUTOCOOKING_Button_select (void)
{
	fillRoundRect(10, 18, 140, 20, 8, GREEN);
	ST7735_WriteString(15, 19, "AUTOCOOKING", Font_11x18, BLACK, GREEN);
	autocookingbtn = 1;
}
void MANUAL_Button_unselect (void)
{
	fillRoundRect(10, 40, 140, 20, 8, RED);
	ST7735_WriteString(15, 41, "MANUAL", Font_11x18, WHITE, RED);
	manualbtn = 0;
}

void MANUAL_Button_select (void)
{
	fillRoundRect(10, 40, 140, 20, 8, GREEN);
	ST7735_WriteString(15, 41, "MANUAL", Font_11x18, BLACK, GREEN);
	manualbtn = 1;
}
void SETTING_Button_unselect (void)
{
	fillRoundRect(10, 62, 140, 20, 8, RED);
	ST7735_WriteString(15, 63, "SETTING", Font_11x18, WHITE, RED);
	settingbtn = 0;
}
void SETTING_Button_select (void)
{
	fillRoundRect(10, 62, 140, 20, 8, GREEN);
	ST7735_WriteString(15, 63, "SETTING", Font_11x18, BLACK, GREEN);
	settingbtn = 1;
}
void RCOUNTER_Button_unselect (void)
{
	fillRoundRect(10, 84, 140, 20, 8, RED);
	ST7735_WriteString(15, 85, "RECIPE COUNT", Font_11x18, WHITE, RED);
	rcounterbtn = 0;
}
void RCOUNTER_Button_select (void)  {
	fillRoundRect(10, 84, 140, 20, 8, GREEN);
	ST7735_WriteString(15, 85, "RECIPE COUNT", Font_11x18, BLACK, GREEN);
	rcounterbtn = 1;
}
/////////////////////////////////////////////////////////////NEXT PAGE///////////////////////////////////////////////
void RECIPE1_UNSELECT (void)  {
    fillRoundRect(10, 18, 140, 20, 8, RED);
	ST7735_WriteString(15, 19, "recipe1", Font_11x18, WHITE, RED);
	recipe1 = 0;
}
void RECIPE1_SELECT (void)
{
	fillRoundRect(10, 18, 140, 20, 8, GREEN);
		ST7735_WriteString(15, 19, "recipe1", Font_11x18, BLACK, GREEN);
	recipe1 = 1;
}
void RECIPE2_UNSELECT (void)  {
	fillRoundRect(10, 40, 140, 20, 8, RED);
		ST7735_WriteString(15, 41, "recipe2", Font_11x18, WHITE, RED);
	recipe2 = 0;
}
void RECIPE2_SELECT (void)
{
	fillRoundRect(10, 40, 140, 20, 8, GREEN);
		ST7735_WriteString(15, 41, "recipe2", Font_11x18, BLACK, GREEN);
	recipe2 = 1;
}
void RECIPE3_UNSELECT (void)  {
	fillRoundRect(10, 62, 140, 20, 8, RED);
		ST7735_WriteString(15, 63, "recipe3", Font_11x18, WHITE, RED);
	recipe3 = 0;
}
void RECIPE3_SELECT (void)  {
	fillRoundRect(10, 62, 140, 20, 8, GREEN);
		ST7735_WriteString(15, 63, "recipe3", Font_11x18, BLACK, GREEN);
	recipe3 = 1;
}
void RECIPE4_SELECT (void)
{
	fillRoundRect(10, 84, 140, 20, 8, GREEN);
		ST7735_WriteString(15, 85, "recipe4", Font_11x18, BLACK, GREEN);
	recipe4 = 1;
}
void RECIPE4_UNSELECT (void)  {
	fillRoundRect(10, 84, 140, 20, 8, RED);
		ST7735_WriteString(15, 85, "recipe4", Font_11x18, WHITE, RED);
	recipe4 = 0;
}
void RECIPE5_SELECT (void)
{
	fillRoundRect(10, 106, 140, 20, 8, GREEN);
		ST7735_WriteString(15, 107, "recipe5", Font_11x18, BLACK, GREEN);
	recipe5 = 1;
}
void RECIPE5_UNSELECT (void)  {
	fillRoundRect(10, 106, 140, 20, 8, RED);
		ST7735_WriteString(15, 107, "recipe5", Font_11x18, WHITE, RED);
	recipe5 = 0;
}

/////////////////////////////////////
void RECIPE_SETTING_UNSELECT (void)  {
	 fillRoundRect(10, 18, 140, 20, 8, RED);
		ST7735_WriteString(15, 19, "Recipe_Set", Font_11x18, WHITE, RED);
	recipesetting = 0;
}
void RECIPE_SETTING_SELECT (void)
{
	fillRoundRect(10, 18, 140, 20, 8, GREEN);
			ST7735_WriteString(15, 19, "Recipe_Set", Font_11x18, BLACK, GREEN);
	recipesetting = 1;
}
void PREHEATING_SETTING_UNSELECT (void)  {
	fillRoundRect(10, 40, 140, 20, 8, RED);
			ST7735_WriteString(15, 41, "Preheat_Set", Font_11x18, WHITE, RED);
	preheatingsetting = 0;
}
void PREHEATING_SETTING_SELECT (void)
{
	fillRoundRect(10, 40, 140, 20, 8, GREEN);
			ST7735_WriteString(15, 41, "Preheat_Set", Font_11x18, BLACK, GREEN);
	preheatingsetting = 1;
}
void SLEEPTIMER_UNSELECT (void)  {
	fillRoundRect(10, 62, 140, 20, 8, RED);
			ST7735_WriteString(15, 63, "Sleeptime", Font_11x18, WHITE, RED);
	sleeptimer = 0;
}
void SLEEPTIMER_SELECT (void)  {
	fillRoundRect(10, 62, 140, 20, 8, GREEN);
			ST7735_WriteString(15, 63, "Sleeptime", Font_11x18, BLACK, GREEN);
	sleeptimer = 1;
}

void SETTEMP_UNSELECT (void)
{
	fillRoundRect(16, 71, 59, 25, 8, RED);
	ST7735_WriteString(30, 75, "OK", Font_11x18, WHITE, RED);
	settemp = 0;
}
void SETTEMP_SELECT (void)
{

	fillRoundRect(16, 71, 59, 25, 8, GREEN);
	ST7735_WriteString(30, 75, "OK", Font_11x18, BLACK, GREEN);
	settemp = 1;
}
void MANUALSTART_UNSELECT (void)
{
    fillRoundRect(80, 71, 64, 25, 8, RED);
    ST7735_WriteString(83, 75, "Start", Font_11x18, WHITE, RED);
    manualstart=0;
}
void MANUALSTART_SELECT (void)
{
    fillRoundRect(80, 71, 64, 25, 8, GREEN);
    ST7735_WriteString(83, 75, "Start", Font_11x18, BLACK, GREEN);
    manualstart=1;
}
////////////////////////
void PORTION1_Button_unselect (void)  {
	 fillRoundRect(10, 18, 140, 20, 8, RED);
		ST7735_WriteString(15, 19, "Portion 1", Font_11x18, WHITE, RED);
	portion1btn = 0;
}

void PORTION1_Button_select (void)
{
	fillRoundRect(10, 18, 140, 20, 8, GREEN);
			ST7735_WriteString(15, 19, "Portion 1", Font_11x18, BLACK, GREEN);
	portion1btn = 1;
}
void PORTION2_Button_unselect (void)  {
	fillRoundRect(10, 40, 140, 20, 8, RED);
			ST7735_WriteString(15, 41, "Portion 2", Font_11x18, WHITE, RED);
	portion2btn = 0;
}

void PORTION2_Button_select (void)
{
	fillRoundRect(10, 40, 140, 20, 8, GREEN);
				ST7735_WriteString(15, 41, "Portion 2", Font_11x18, BLACK, GREEN);
	portion2btn = 1;
}
void PORTION3_Button_unselect (void)  {
	fillRoundRect(10, 62, 140, 20, 8, RED);
			ST7735_WriteString(15, 63, "Portion 3", Font_11x18, WHITE, RED);
	portion3btn = 0;
}
void PORTION3_Button_select (void)  {
	fillRoundRect(10, 62, 140, 20, 8, GREEN);
			ST7735_WriteString(15, 63, "Portion 3", Font_11x18, BLACK, GREEN);
	portion3btn = 1;
}
void TEMPRETURE (void)  {
	T=Max6675_Read_Temp();
sprintf(temp,"%u    ",T);
	ST7735_WriteString(30, 0, temp, Font_7x10, GREEN, BLACK);
	ST7735_WriteString(0, 0, "T=", Font_7x10, GREEN, BLACK);
	ST7735_WriteString(50, 0, "*C", Font_7x10, GREEN, BLACK);

}
void t (void)  {
	 time_value=0;
	 time_value = __HAL_TIM_GET_COUNTER(&htim2);  //to get the timer value
	 time_value = time_value/1000;
     escaped_time =  time - time_value ;
ST7735_WriteString(10, 60, "Timer=", Font_11x18, GREEN, BLACK);
ST7735_WriteString(20, 40, "Temp", Font_11x18, GREEN, BLACK);
sprintf(tm,"%u    ",escaped_time);
 ST7735_WriteString(90, 60, tm, Font_11x18, RED, BLACK);
  HAL_Delay (200);
// time1 =Flash_Read_NUM(0x0800FC00);
//  time1 = RxVal1;


          if (time>time_value)
          {

         	HAL_TIM_Base_Start_IT(&htim2);
         	ST7735_WriteString(30, 100, "Deep1", Font_11x18, RED, BLACK);
         	if (limitdown)
         	{
         	 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, 0);   //down
         	}
         	else
         	{
         	 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, 1);
         	}///set a pin for
           }
         else if (time<=time_value)
           {
            	 HAL_TIM_Base_Stop_IT(&htim2);
            	 HAL_Delay (200);
            	portionpager111=1;
            	__HAL_TIM_SET_COUNTER(&htim2,0);
	          enter = 0;
           portion1btn = 0;
           portionpager11=0;
          }
          if (back)
             {
     	            portionpager11 = 0;
                   portionpager1 = 1;
                              back = 0;
                   HAL_TIM_Base_Stop_IT(&htim2);
                   time_value=0;
                   __HAL_TIM_SET_COUNTER(&htim2,0);
                   }
}

void t1 ()
{
	time_value=0;

time_value = __HAL_TIM_GET_COUNTER(&htim2);  //to get the timer value
time_value = time_value/1000;
escaped_time =  time - time_value ;
ST7735_WriteString(10, 60, "Timer=", Font_11x18, GREEN, BLACK);
ST7735_WriteString(20, 40, "Temp", Font_11x18, GREEN, BLACK);
sprintf(tm,"%u    ",escaped_time);
ST7735_WriteString(90, 60, tm, Font_11x18, RED, BLACK);
HAL_Delay (200);
if (time>time_value)
      {
     	HAL_TIM_Base_Start_IT(&htim2);
     	ST7735_WriteString(30, 100, "steam", Font_11x18, RED, BLACK);
     	if (limitup)
     	{
     	 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, 0);   //down
     	}
     	else
     	{
     	 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, 1);
     	}
       }
     else if (time<=time_value)
       {
        	 HAL_TIM_Base_Stop_IT(&htim2);    ///stop the timer
   	portionpager112=1;
  __HAL_TIM_SET_COUNTER(&htim2,0);
portionpager111 = 0;
          enter = 0;
       portion1btn = 0;
      }
      if (back)
         {
 	            portionpager111 = 0;
               portionpager1 = 1;
                          back = 0;
               HAL_TIM_Base_Stop_IT(&htim2);
               time_value=0;
               __HAL_TIM_SET_COUNTER(&htim2,0);
               }

}

void t2(void)
{
	time_value=0;

	time_value = __HAL_TIM_GET_COUNTER(&htim2);  //to get the timer value
	time_value = time_value/1000;
	escaped_time =  time - time_value ;
	ST7735_WriteString(10, 60, "Timer=", Font_11x18, GREEN, BLACK);
	ST7735_WriteString(20, 40, "Temp", Font_11x18, GREEN, BLACK);
	sprintf(tm,"%u    ",escaped_time);
	ST7735_WriteString(90, 60, tm, Font_11x18, RED, BLACK);
	HAL_Delay (200);
	if (time>time_value)
      {
     	HAL_TIM_Base_Start_IT(&htim2);
     	ST7735_WriteString(30, 100, "Deep2", Font_11x18, RED, BLACK);
     	if (limitdown)
     	{
     	 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, 0);   //down
     	}
     	else
     	{
     	 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, 1);
     	}///set a pin for
       }
     else if (time<=time_value)
       {
        	 HAL_TIM_Base_Stop_IT(&htim2);
        ST7735_WriteString(30, 100, "Cooked", Font_11x18, RED, BLACK);
          if (limitdown)
         	{

      	 HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, 0);
         	}
         	else
         	{
      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, 1);

         		}
          enter = 0;
       portion1btn = 0;
       portionpager11=0;
      }
      if (back)
         {
 	            portionpager112 = 0;
               portionpager1 = 1;
                          back = 0;
               HAL_TIM_Base_Stop_IT(&htim2);
               time_value=0;
               __HAL_TIM_SET_COUNTER(&htim2,0);
               }
}
//////////////////////////////////////////////////////////////////////////////******pages******/

void HomeMenu (void)
{

     TEMPRETURE();
	ST7735_WriteString(35, 30, "AUTOMATED", Font_11x18, GREEN, BLACK);
	ST7735_WriteString(55, 50, "FRYER", Font_11x18, GREEN, BLACK);

	homemenu = 1;
	page2menu = 0;
	testmenu = 0;
	page3menu =0;
	page4menu = 0;
	page5menu = 0;
	portionpager1 = 0;
		portionpager2 = 0;
		portionpager3 = 0;
		recipesettingpage = 0;
		preheatingsettingpage=0;
						recipe1setting =0;
					    recipe2setting =0;
					    recipe3setting =0;
}
void testMenu(void)
{
	homemenu = 0;
	page2menu = 0;
	testmenu = 1;
	page3menu =0;
	page4menu = 0;
	page5menu = 0;
	portionpager1 = 0;
	recipesettingpage = 0;
		portionpager2 = 0;
		portionpager3 = 0;
		preheatingsettingpage=0;
						recipe1setting =0;
					    recipe2setting =0;
					    recipe3setting =0;
	TEMPRETURE();
    ST7735_WriteString(20, 30, "ADD OIL FOR", Font_11x18, GREEN, BLACK);
    ST7735_WriteString(40, 50, "HEATING", Font_11x18, GREEN, BLACK);
	P1Heat_Button_unselect();


}
void Page2Menu (void)               //for autocooking,manual,machine setting,recipecontrol selection
{
	homemenu = 0;
	page2menu = 1;
	testmenu = 0;
	page3menu =0;
	page4menu = 0;
	page5menu = 0;
	portionpager1 = 0;
	recipesettingpage = 0;
		portionpager2 = 0;
		portionpager3 = 0;
		preheatingsettingpage=0;
						recipe1setting =0;
					    recipe2setting =0;
					    recipe3setting =0;

	TEMPRETURE();
    AUTOCOOKING_Button_unselect();
    MANUAL_Button_unselect();
	SETTING_Button_unselect();
	RCOUNTER_Button_unselect();


}
void Page3Menu (void)                  //for reicpe selection
{
	homemenu = 0;
	testmenu = 0;
	page2menu = 0;
	page3menu= 1;
	page4menu = 0;
	page5menu = 0;
	portionpager1 = 0;
	recipesettingpage = 0;
	preheatingsettingpage=0;
					recipe1setting =0;
				    recipe2setting =0;
				    recipe3setting =0;
		portionpager2 = 0;
		portionpager3 = 0;


		TEMPRETURE();
		RECIPE1_UNSELECT();
		RECIPE2_UNSELECT();
		RECIPE3_UNSELECT();
       RECIPE4_UNSELECT();
		RECIPE5_UNSELECT();

}
void Page4Menu (void)         //for machine setting(recipe setting,preheating setting, sleep time)
{
	homemenu = 0;
	testmenu = 0;
	page2menu = 0;
	page3menu= 0;
	page4menu = 1;
	page5menu = 0;
	portionpager1 = 0;
		portionpager2 = 0;
		portionpager3 = 0;
		recipesettingpage = 0;
		preheatingsettingpage=0;
						recipe1setting =0;
					    recipe2setting =0;
					    recipe3setting =0;

		RECIPE_SETTING_UNSELECT();
		PREHEATING_SETTING_UNSELECT();
		SLEEPTIMER_UNSELECT();
		TEMPRETURE();
}
void Page5Menu (void)    ////mannual poage
{
	homemenu = 0;
	testmenu = 0;
	page2menu = 0;
	page3menu= 0;
	page4menu = 0;
	page5menu = 1;
	portionpager1 = 0;
	portionpager2 = 0;
	portionpager3 = 0;
	recipesettingpage = 0;
	preheatingsettingpage=0;


		ST7735_WriteString(00, 10, "SET TEMPRETURE", Font_11x18, GREEN, BLACK);
		sprintf(tem,"%u    ",tempreture);
	    ST7735_WriteString(75, 40, tem, Font_11x18, GREEN, BLACK);

		SETTEMP_UNSELECT();
		MANUALSTART_UNSELECT();
		TEMPRETURE();
}
void PortionPageR1 (void)
{

			page3menu =0;
		portionpager1 = 1;
			portionpager2 = 0;
			portionpager3 = 0;
			portionpager4 = 0;
						portionpager5 = 0;
						recipesettingpage = 0;


				PORTION1_Button_unselect();
				PORTION2_Button_unselect();
				PORTION3_Button_unselect();
}
void PortionPageR2 (void)
{
	homemenu = 0;
		page3menu = 0;
		portionpager2 = 1;
		portionpager1 = 0;
			portionpager3 = 0;
			portionpager4 = 0;
						portionpager5 = 0;
			recipesettingpage = 0;
			preheatingsettingpage=0;
							recipe1setting =0;
						    recipe2setting =0;
						    recipe3setting =0;

				PORTION1_Button_unselect();
				PORTION2_Button_unselect();
				PORTION3_Button_unselect();
}

void PortionPage11 (void)
{
	homemenu = 0;
	testmenu = 0;
	page3menu =0;
	page4menu = 0;
	page5menu = 0;
		portionpager1 = 0;
		portionpager11 = 1;
		portionpager111 = 0;
		portionpager12 = 0;
			portionpager2 = 0;
			portionpager3 = 0;
			recipesettingpage = 0;
			preheatingsettingpage=0;


                time=10;

				 TEMPRETURE();
}
void PortionPage111 (void)
{

		portionpager1 = 0;
		portionpager11 = 0;
		portionpager111 = 1;
		portionpager112 = 0;

				 TEMPRETURE();
				 time=20;
}
void PortionPage112 (void)
{
		portionpager1 = 0;
		portionpager11 = 0;
		portionpager111 = 0;
		portionpager112 = 1;
		portionpager12 = 0;
		 TEMPRETURE();
					  time=40;
}
void PortionPage12 (void)
{
		portionpager1 = 0;
		portionpager11 = 0;
		portionpager111 = 0;
		portionpager12 = 1;
	     portionpager2 = 0;



                TEMPRETURE();
}
void PortionPage121 (void)
{
		portionpager12 = 0;
		portionpager121 = 1;
		portionpager122 = 0;

				 TEMPRETURE();
}
void PortionPage122 (void)
{
		portionpager1 = 0;
				portionpager12 = 0;
				portionpager121 = 0;
				portionpager122 = 1;
				portionpager13 = 0;

				 TEMPRETURE();
}
void PortionPage13 (void)
{

				portionpager13 = 1;
				portionpager131 = 0;
				portionpager132 = 0;
			portionpager2 = 0;
			portionpager3 = 0;

                 TEMPRETURE();
}
void PortionPage131 (void)
{

				portionpager13 = 0;
				portionpager131 = 1;
				portionpager132 = 0;

				 TEMPRETURE();
}
void PortionPage132 (void)
{
				portionpager13 = 0;
				portionpager131 = 0;
				portionpager132 = 1;
		      TEMPRETURE();
}
void PortionPage21 (void)
{
						portionpager21 = 1;
						portionpager211 = 0;
						portionpager212 = 0;

			portionpager2 = 0;
			portionpager3 = 0;
		        TEMPRETURE();
}
void PortionPage211 (void)
{
						portionpager21 = 0;
						portionpager211 = 1;
						portionpager212 = 0;
						portionpager22 = 0;
						portionpager221 = 0;
						portionpager222 = 0;

			portionpager2 = 0;
			portionpager3 = 0;


								 TEMPRETURE();
}

void PortionPage212 (void)
{
						portionpager21 = 0;
						portionpager211 = 0;
						portionpager212 = 1;
						portionpager22 = 0;
			            portionpager2 = 0;

								 TEMPRETURE();
}

void PortionPage22 (void)
{
								portionpager211 = 0;
								portionpager212 = 0;
								portionpager22 = 1;
								portionpager221 = 0;
								portionpager222 = 0;
		portionpager12 = 0;
			portionpager2 = 0;
			portionpager3 = 0;

                				 TEMPRETURE();
}
void PortionPage221 (void)
{
								portionpager211 = 0;
								portionpager212 = 0;
								portionpager22 = 0;
								portionpager221 = 1;
								portionpager222 = 0;
			portionpager2 = 0;
			portionpager3 = 0;

                				 TEMPRETURE();
}
void PortionPage222 (void)
{portionpager211 = 0;
								portionpager212 = 0;
								portionpager22 = 0;
								portionpager221 = 0;
								portionpager222 = 1;
			portionpager2 = 0;
			portionpager3 = 0;

                 TEMPRETURE();
}

void PortionPage23 (void)
{
		portionpager1 = 0;
		portionpager23 = 1;
		portionpager21 = 0;
								portionpager231 = 0;
								portionpager232 = 0;
		portionpager12 = 0;
			portionpager2 = 0;
			portionpager3 = 0;

                	 TEMPRETURE();
}
void PortionPage231 (void)
{
		portionpager23 = 0;
								portionpager231 = 1;
								portionpager232 = 0;

                 TEMPRETURE();
}
void PortionPage232 (void)
{
		portionpager23 = 0;
		portionpager21 = 0;
		portionpager231 = 0;
		portionpager232 = 1;
			portionpager2 = 0;
			portionpager3 = 0;

                TEMPRETURE();
}
void PortionPageR3 (void)
{
		page3menu = 0;
		portionpager2 = 0;
		portionpager1 = 0;
			portionpager3 = 1;
			portionpager4 = 0;
						portionpager5 = 0;

			recipesettingpage = 0;
			preheatingsettingpage=0;
							recipe1setting =0;
						    recipe2setting =0;
						    recipe3setting =0;

				PORTION1_Button_unselect();
				PORTION2_Button_unselect();
				PORTION3_Button_unselect();
}
void PortionPage31 (void)
{
		portionpager31 =1;
		portionpager311 = 0;
		portionpager312 = 0;

			portionpager2 = 0;
			portionpager3 = 0;
			recipesettingpage = 0;
			preheatingsettingpage=0;

				 TEMPRETURE();
}
void PortionPage311 (void)
{
		portionpager31 =0;
		portionpager21 = 0;
								portionpager311 = 1;
								portionpager312 = 0;



								 TEMPRETURE();
}
void PortionPage312 (void)
{
		portionpager31 =0;
		portionpager311 = 0;
		portionpager312 = 1;
			portionpager3 = 0;


								 TEMPRETURE();
}
void PortionPage32 (void)
{
		portionpager32 = 1;
			portionpager2 = 0;
			portionpager3 = 0;

				TEMPRETURE();
}
void PortionPage321 (void)
{
		portionpager31 =0;
								portionpager321 = 1;
								portionpager322 = 0;
			portionpager3 = 0;

								 TEMPRETURE();
}
void PortionPage322 (void)
{
		portionpager31 =0;
        portionpager311 = 0;
        portionpager322 = 1;
			portionpager3 = 0;


								 TEMPRETURE();
}
void PortionPage33 (void)
{

			portionpager2 = 0;
			portionpager33 = 1;


                				 TEMPRETURE();
}
void PortionPage331 (void)
{
		portionpager31 =0;
	   portionpager331 = 1;
        portionpager332 = 0;

								 TEMPRETURE();
}
void PortionPage332 (void)
{
		portionpager332 =1;
	     portionpager331 = 0;
			portionpager3 = 0;


								 TEMPRETURE();
}
////////////////for recipe 4
void PortionPageR4 (void)
{
		page5menu = 0;
		portionpager2 = 0;
		portionpager1 = 0;
			portionpager4 = 1;
			portionpager3 = 0;
			portionpager5 = 0;
			recipesettingpage = 0;

				PORTION1_Button_unselect();
				PORTION2_Button_unselect();
				PORTION3_Button_unselect();
				TEMPRETURE();
}
void PortionPage41 (void)
{
		portionpager41 =1;
		portionpager411 = 0;
		portionpager412 = 0;

			portionpager3 = 0;
			portionpager4 = 0;
			recipesettingpage = 0;
			preheatingsettingpage=0;

				 TEMPRETURE();
}
void PortionPage411 (void)
{
		portionpager41 =0;
		portionpager31 = 0;
								portionpager411 = 1;
								portionpager412 = 0;



								 TEMPRETURE();
}
void PortionPage412 (void)
{
		portionpager41 =0;
		portionpager411 = 0;
		portionpager412 = 1;
			portionpager4 = 0;


								 TEMPRETURE();
}
void PortionPage42 (void)
{
		portionpager42 = 1;
			portionpager2 = 0;
			portionpager4 = 0;

				TEMPRETURE();
}
void PortionPage421 (void)
{
		portionpager41 =0;
								portionpager421 = 1;
								portionpager422 = 0;
			portionpager4 = 0;

								 TEMPRETURE();
}
void PortionPage422 (void)
{
		portionpager41 =0;
        portionpager411 = 0;
        portionpager422 = 1;
			portionpager4 = 0;

								 TEMPRETURE();
}
void PortionPage43 (void)
{

			portionpager4 = 0;
			portionpager43 = 1;

                				 TEMPRETURE();
}
void PortionPage431 (void)
{
		portionpager41 =0;
	   portionpager431 = 1;
        portionpager432 = 0;

								 TEMPRETURE();
}
void PortionPage432 (void)
{
		portionpager432 =1;
	     portionpager431 = 0;
			portionpager4 = 0;


								 TEMPRETURE();
}
void PortionPageR5 (void)
{
		page5menu = 0;
		portionpager2 = 0;
		portionpager1 = 0;
			portionpager5 = 1;
			portionpager3 = 0;

			recipesettingpage = 0;

				PORTION1_Button_unselect();
				PORTION2_Button_unselect();
				PORTION3_Button_unselect();
				TEMPRETURE();
}
void PortionPage51 (void)
{
		portionpager51 =1;
		portionpager511 = 0;
		portionpager512 = 0;

			portionpager3 = 0;
			portionpager5 = 0;
			recipesettingpage = 0;
			preheatingsettingpage=0;

				 TEMPRETURE();
}
void PortionPage511 (void)
{
		portionpager51 =0;
		portionpager31 = 0;
								portionpager511 = 1;
								portionpager512 = 0;



								 TEMPRETURE();
}
void PortionPage512 (void)
{
		portionpager51 =0;
		portionpager511 = 0;
		portionpager512 = 1;
			portionpager5 = 0;


								 TEMPRETURE();
}
void PortionPage52 (void)
{
		portionpager52 = 1;
			portionpager2 = 0;
			portionpager5 = 0;

				TEMPRETURE();
}
void PortionPage521 (void)
{
		portionpager51 =0;
								portionpager521 = 1;
								portionpager522 = 0;
			portionpager5 = 0;

								 TEMPRETURE();
}
void PortionPage522 (void)
{
		portionpager51 =0;
        portionpager511 = 0;
        portionpager522 = 1;
			portionpager5 = 0;

								 TEMPRETURE();
}
void PortionPage53 (void)
{

			portionpager5 = 0;
			portionpager53 = 1;

                				 TEMPRETURE();
}
void PortionPage531 (void)
{
		portionpager51 =0;
	   portionpager531 = 1;
        portionpager532 = 0;

								 TEMPRETURE();
}
void PortionPage532 (void)
{
		portionpager532 =1;
	     portionpager531 = 0;
			portionpager5 = 0;


								 TEMPRETURE();
}

void RECIPE_SETTING_PAGE (void)
{
	homemenu = 0;
			testmenu = 0;
			page2menu = 0;
			page3menu= 0;
			page4menu = 0;
			page5menu = 0;
			portionpager1 = 0;
				portionpager2 = 0;
				portionpager3 = 0;
				recipesettingpage = 1;
				preheatingsettingpage=0;
				recipe1setting =0;
			    recipe2setting =0;
			    recipe3setting =0;

						RECIPE1_UNSELECT();
						RECIPE2_UNSELECT();
						RECIPE3_UNSELECT();


}
void RECIPE1SETTING (void)
{
	homemenu = 0;
		testmenu = 0;
		page2menu = 0;
		page3menu= 0;
		page4menu = 0;
		page5menu = 0;
		portionpager3 = 0;
		portionpager1 = 0;
			portionpager2 = 0;
			recipesettingpage = 0;
		    recipe1setting =1;
		    recipe2setting =0;
		    recipe3setting =0;
		    preheatingsettingpage=0;

				PORTION1_Button_unselect();
				PORTION2_Button_unselect();
				PORTION3_Button_unselect();
}
void RECIPE2SETTING (void)
{
	homemenu = 0;
		testmenu = 0;
		page2menu = 0;
		page3menu= 0;
		page4menu = 0;
		page5menu = 0;
		portionpager3 = 0;
		portionpager1 = 0;
			portionpager2 = 0;
			recipesettingpage = 0;
		    recipe1setting =0;
		    recipe2setting =1;
		    recipe3setting =0;
		    preheatingsettingpage=0;
		     PORTION1_Button_unselect();
				PORTION2_Button_unselect();
				PORTION3_Button_unselect();
}
void RECIPE3SETTING (void)
{
	homemenu = 0;
		testmenu = 0;
		page2menu = 0;
		page3menu= 0;
		page4menu = 0;
		page5menu = 0;
		portionpager3 = 0;
		portionpager1 = 0;
			portionpager2 = 0;
			recipesettingpage = 0;
		    recipe1setting =0;
		    recipe2setting =0;
		    recipe3setting =1;
		    preheatingsettingpage=0;
		       PORTION1_Button_unselect();
				PORTION2_Button_unselect();
				PORTION3_Button_unselect();

}
 void Preheatingsettingpage (void)
 {
	 homemenu = 0;
	 		testmenu = 0;
	 		page2menu = 0;
	 		page3menu= 0;
	 		page4menu = 0;
	 		page5menu = 0;
	 		portionpager3 = 0;
	 		portionpager1 = 0;
	 	    portionpager2 = 0;
	 			recipesettingpage = 0;
	 		    recipe1setting =0;
	 		    recipe2setting =0;
	 		    recipe3setting =0;
	 		    preheatingsettingpage=1;

	 		  	PREHEATING_SETTING_UNSELECT();


 }





/*******
 *  EXTI callback
 * PA0 is ENTER
 * PA1 is DOWN
 * PA4 is UP
 *******/
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if (GPIO_Pin == GPIO_PIN_0)  // If the PA0 (ENTER) is pressed
	{
		downbutton = 0;
		back = 0;
		enter = 1;
		upbutton=0;
		limitup = 0;
	    limitdown = 0;
	}

	if (GPIO_Pin == GPIO_PIN_1)  // If the PA1 (DOWN) is pressed
	{
		downbutton = 1;
		back = 0;
		enter = 0;
		upbutton=0;
		limitup = 0;
	    limitdown = 0;
	}

	if (GPIO_Pin == GPIO_PIN_4)
	{
		downbutton = 0;
		back = 1;  //
		enter = 0;
		upbutton=0;
		limitup = 0;
		limitdown = 0;
	}

	/*if (GPIO_Pin == GPIO_PIN_3)
		{
			downbutton = 0;
			back = 1;
			upbutton=1;
			enter = 0;
			limitup = 0;
			limitdown = 0;
		}*/
//	if (GPIO_Pin == limit_switchsensor2_Pin)
	//{
		//limitup = 1;
		//limitdown = 0;
	//	downbutton = 0;
		//upbutton = 0;
	    //enter = 0;
	//}
	//if (GPIO_Pin == limit_Switchsenor1_Pin)
		//{
		//downbutton = 0;
		//upbutton = 0;
		//enter = 0;
	//	limitup = 0;
		//limitdown = 1;
	//	}
}

void Menu_Handler (void)
{
	ST7735_SetRotation(1);
	fillScreen(BLACK);
//	 Flash_Write_NUM(0x0800FC00, time11);
	//  	  	Flash_Write_NUM(0x0800FC1C, time21);
	  	  	//Flash_Write_NUM(0x0800FC38, time31);
	 tempreture=Max6675_Read_Temp();
	 sprintf(temp,"%u    ",tempreture);


	  if (homemenu)
	  {
		  HomeMenu();


		  while (homemenu)
		  {

		  if (downbutton| back| enter)
		  {
			  HAL_Delay (200);
			   testMenu();

			  upbutton=0;
			  downbutton=0;
			  enter=0;


		  }}}
	  else   if(testmenu)
				  {
			        testMenu();


			        while(testmenu)
			        {
			        	HAL_Delay (200);
				       if(enter)
					      {

				    	   HAL_Delay (200);
				    	   homemenu=0;
				    	   heatbutton=1;

			         	    	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, 1);
			         	    	P1Heat_Button_unselect();
			         	    	enter = 0;
			         	    	Page2Menu();
			         	     }
					      }
			           }


		  else  if (page2menu)
			           {
			    	    Page2Menu();
			           while(page2menu)
			           {
			        	   HAL_Delay(200);
			        	   if (downbutton)
			        	   		  {
			        	   			     HAL_Delay(200);
			        	   			  if (autocookingbtn)
			        	   			       {
			        	   				       MANUAL_Button_select();
			        	   				       AUTOCOOKING_Button_unselect();
			        	   				       downbutton = 0;
			        	   				       autocookingbtn = 0;
			        	   			        }
			        	   	           else if (manualbtn)
			        	   						  {
			        	   	        	              MANUAL_Button_unselect();
			        	   	        	              SETTING_Button_select();
			        	   							  downbutton = 0;
			        	   							  manualbtn = 0;
			        	   						  }

			        	   	           else if (settingbtn)
			        	   	        			  {
			        	   	        			       SETTING_Button_unselect();
			           	   	        	               RCOUNTER_Button_select();
			        	   	        			       downbutton = 0;
			        	   	        			       settingbtn = 0;
			        	   	        			    }

			        	   	              else if (rcounterbtn)
			        	   	        			   {
			        	   	        			        RCOUNTER_Button_unselect();
			        	   	        			     AUTOCOOKING_Button_select();
			        	   	        			         downbutton = 0;
			        	   	        			         rcounterbtn = 0;
			        	   	        			   }

			        	   	              else
			        	   	                 {
			        	   	            	    RCOUNTER_Button_unselect();
			        	   	            	     MANUAL_Button_unselect();
			        	   	            	    SETTING_Button_unselect();
			        	   	                    AUTOCOOKING_Button_select();
      	   	        			                downbutton = 0;
			        	   	                   }
			        	   		            }
			        	   else if (back)
			        	   {
			        		   testmenu = 1;
			        		    page2menu = 0;
			        		    back = 0;

			        	   }

			        	   else if (enter){

			        		   if (autocookingbtn)
			        		   			  {
			        		   				  page3menu = 1;
			        		   				  page2menu = 0;
			        		   				  enter = 0;
			        		   				  autocookingbtn = 0;
			        		   				  manualbtn=0;
			        		   			  }
			        		   else if (manualbtn)
			        		   			  {
			        		   				  page5menu = 1;
			        		   				  page2menu = 0;
			        		   				  enter = 0;
			        		   				  manualbtn = 0;
			        		   				  autocookingbtn=0;
			        		   			  }
			        		   else if (settingbtn)
			        		  		  {
			        		  			    page4menu = 1;
			        		  			    page2menu = 0;
			        		  			    enter = 0;
			        		  		         settingbtn = 0;
			        		  		    }

			        		   else if (rcounterbtn)
			        		   		  {
			        		   			    rcounterbtn = 1;
			        		   			    page2menu = 0;
			        		   			    enter = 0;
			        		   			    rcounterbtn = 0;
			        		   	       }


			        		   else;
			        	   }
			           }
			        }
	    else if (page3menu)
       	  {
       		  Page3Menu();
       		  while (page3menu)
       		  {
       			HAL_Delay(200);
       			if (downbutton)
       			      {
       					  HAL_Delay (200);
       					if (recipe1)
       						    {
       						        RECIPE2_SELECT();
       						        RECIPE1_UNSELECT();
       						         downbutton = 0;
       						         recipe1 = 0;
       						     }
       					else if (recipe2)
       						    {
       						         RECIPE2_UNSELECT();
       						         RECIPE3_SELECT();
       						         downbutton = 0;
       						         recipe2 = 0;
       						      }


       					else if (recipe3)
       					         {
       					       						         RECIPE3_UNSELECT();
       					       						   RECIPE4_SELECT();
       					       						         downbutton = 0;
       					       						         recipe3 = 0;
       					       	   }
               else if (recipe4)
				    {
				         RECIPE4_UNSELECT();
				         RECIPE5_SELECT();
				         downbutton = 0;
				         recipe4 = 0;
				      }


			else if (recipe5)
			         {
			       						         RECIPE5_UNSELECT();
			       						   RECIPE1_SELECT();
			       						         downbutton = 0;
			       						         recipe5 = 0;
			       	   }


       					    else
       					    {
       					    	RECIPE1_SELECT();
       					        RECIPE2_UNSELECT();
       					     RECIPE3_UNSELECT();
       					     RECIPE4_UNSELECT();
       					  RECIPE5_UNSELECT();

       					downbutton = 0;
       			                      }}

       		  else if (back)
       					        	   {
       			  page2menu = 1;
       		    page3menu = 0;
       		  back = 0;


       					        	   }


       		 else if (enter){

       				    if (recipe1)
         		   			  {
       	 		   				  portionpager1 = 1;
       	   		   				  page3menu = 0;
         		   				  enter = 0;
        		   				  recipe1 = 0;
       			  			  }
       			      else if (recipe2)
       	    		   			  {
       			     				  portionpager2 = 1;
       						          page3menu = 0;
       					 			  enter = 0;
       				   				  recipe2 = 0;
       							  }
       				   else if (recipe3)
       				      		  {
       						            portionpager3 = 1;
       						            page3menu = 0;
       						            enter = 0;
       						             recipe3 = 0;
       					  		    }
       				   else if (recipe4)
         	    		   			  {
         			     				  portionpager4 = 1;
         						          page3menu = 0;
         					 			  enter = 0;
         				   				  recipe4 = 0;
         							  }
         				   else if (recipe5)
         				      		  {
         						            portionpager5 = 1;
         						            page3menu = 0;
         						            enter = 0;
         						             recipe5 = 0;
         					  		    }

       						        		else;

       						        	   }
       						         }
       						    }

			    else if (portionpager1)
                   	  {
                   		  PortionPageR1();
                   		  while (portionpager1)
                   		  {
                   			HAL_Delay(200);
                   			if (downbutton)
                   			      {
                   				HAL_Delay (200);
                   					if (portion1btn)
                   						    {
                   						         PORTION1_Button_unselect();
                   						         PORTION2_Button_select();
                   						         downbutton = 0;
                   						         portion1btn = 0;
                   						     }
                   					else if (portion2btn)
                   						    {
                   						          PORTION2_Button_unselect();
                   						          PORTION3_Button_select();
                   						         downbutton = 0;
                   						         portion2btn = 0;
                   						      }


                   					else if (portion3btn)
                   					         {
                   						             PORTION3_Button_unselect();
                   						          PORTION1_Button_select();
                   					                    downbutton = 0;
                   					       			   portion3btn = 0;
                   					       	   }

                   					else
                   					{

                   						PORTION1_Button_select();
                   						PORTION3_Button_unselect();
                   						PORTION2_Button_unselect();
                   						downbutton = 0;
                   					}
                   			      }
                   		 else if (back)
                   		     {
                   			       page3menu = 1;
                   			       portionpager1 = 0;
                   			       back = 0;

                   		        }

                   			else if (enter)
                                      {
                        	              if (portion1btn)
                        	       	          {
                        	            	  portionpager1=0;
                        	            	  portionpager11=1;
                        	            	  enter=0;
                        	       	          }

                        	                else if (portion2btn)
                        	       	       	  {
                        	                	 portionpager1=0;
                        	                   	  portionpager12=1;
                        	                	    	  enter=0;
     	                        	       	          }

                        	                else if (portion3btn)
                        	                   {
                        	                	 portionpager1=0;
                        	                	   portionpager13=1;
                        	                       	  enter=0;
                        	    	       	          }
                       	                    else;

                         } } }

			    else if (portionpager11)
			                    {
			                      PortionPage11();
			                       while (portionpager11)
			                       {
                                       t();

			                      		  }
			                      	  }
			    else if (portionpager111)
			    			                    {
			    			                      PortionPage111();
			    			                       while (portionpager111)
			    			                       {
			                                           HAL_Delay (200);
			                                        t1();

			   			                      		  }
			   			                      	  }
              else if (portionpager112)
              {
                PortionPage112();
                 while (portionpager112)
                 {
                      HAL_Delay (200);
                     // time =Flash_Read_NUM(0x0800FC38);
                    //time3 = RxVal3;
                     t2();

                		  }
                	  }
//////////////////////////////////////////////////////
			 else if (portionpager12)
              {
                PortionPage12();
                 while (portionpager12)
                 {
                      t();
                 }}
else if (portionpager121)
			                    {
			                      PortionPage121();
			                       while (portionpager121)
			                       {
                                   t1();

			                      		  }
			                      	  }
else if (portionpager122)
{
PortionPage122();
while (portionpager122)
{
    t2();
		  }
	  }

			   ////////////////////////////////////
			    else if (portionpager13)
                {
                  PortionPage13();
                   while (portionpager13)
                   {
                       t();
                   }}
else if (portionpager131)
			                    {
			                      PortionPage131();
			                       while (portionpager131)
			                       {
                                      t1();

			                      		  }
			                      	  }
else if (portionpager132)
{
PortionPage132();
 while (portionpager132)
 {
      t2();
		  }
	  }




//////////////////////////////////////portion page for recipe2
else if (portionpager2)
                   	  {
                   		  PortionPageR2();
                   		  while (portionpager2)
                   		  {
                   			HAL_Delay(200);
                   			if (downbutton)
                   			      {
                   				HAL_Delay (200);
                   					if (portion1btn)
                   						    {
                   						         PORTION1_Button_unselect();
                   						         PORTION2_Button_select();
                   						         downbutton = 0;
                   						         portion1btn = 0;
                   						     }
                   					else if (portion2btn)
                   						    {
                   						          PORTION2_Button_unselect();
                   						          PORTION3_Button_select();
                   						         downbutton = 0;
                   						         portion2btn = 0;
                   						      }


                   					else if (portion3btn)
                   					         {
                   						             PORTION3_Button_unselect();
                   						          PORTION1_Button_select();
                   					                    downbutton = 0;
                   					       			   portion3btn = 0;
                   					       	   }

                   					else
                   					{

                   						PORTION1_Button_select();
                   						PORTION3_Button_unselect();
                   						PORTION2_Button_unselect();
                   						downbutton = 0;
                   					}
                   			      }
                   		 else if (back)
                   		     {
                   			       page3menu = 1;
                   			       portionpager2 = 0;
                   			       back = 0;

                   		        }

                   			else if (enter)
                                      {
                        	              if (portion1btn)
                        	       	          {
                        	            	  portionpager2=0;
                        	            	  portionpager21=1;
                        	            	  enter=0;
                        	       	          }

                        	                else if (portion2btn)
                        	       	       	  {
                        	                	 portionpager2=0;
                        	                   	  portionpager22=1;
                        	                	    	  enter=0;
     	                        	       	          }

                        	                else if (portion3btn)
                        	                   {
                        	                	 portionpager2=0;
                        	                	   portionpager23=1;
                        	                       	  enter=0;
                        	    	       	          }
                       	                    else;

                         }
                   		  }
                   	  }

			    else if (portionpager21)
			                    {
			                      PortionPage21();
			                       while (portionpager21)
			                       {
                                       t();

			                      		  }
			                      	  }
			    else if (portionpager211)
			    			                    {
			    			                      PortionPage211();
			    			                       while (portionpager211)
			    			                       {
			                                          t1();

			   			                      		  }
			   			                      	  }
              else if (portionpager212)
              {
                PortionPage212();
                 while (portionpager212)
                 {
                      t2();
                		  }
                	  }
//////////////////////////////////////////////////////
			  else if (portionpager22)
              {
                PortionPage22();
                 while (portionpager22)
                 {
                      t();

                		  }
                	  }
else if (portionpager221)
			                    {
			                      PortionPage221();
			                       while (portionpager221)
			                       {
                                     t1();

			                      		  }
			                      	  }
else if (portionpager222)
{
PortionPage222();
while (portionpager222)
{
   t2();
		  }
	  }

			   ////////////////////////////////////
			    else if (portionpager23)
                {
                  PortionPage23();
                   while (portionpager23)
                   {
                       t();

                  		  }
                  	  }
else if (portionpager231)
			                    {
			                      PortionPage231();
			                       while (portionpager231)
			                       {
                                      t1();

			                      		  }
			                      	  }
else if (portionpager232)
{
PortionPage232();
 while (portionpager232)
 {
      t2();
		  }
	  }
			  ///////////////////////////////////portion page for recipe3
else if (portionpager3)
                   	  {
                   		  PortionPageR3();
                   		  while (portionpager3)
                   		  {
                   			HAL_Delay(200);
                   			if (downbutton)
                   			      {
                   				HAL_Delay (200);
                   					if (portion1btn)
                   						    {
                   						         PORTION1_Button_unselect();
                   						         PORTION2_Button_select();
                   						         downbutton = 0;
                   						         portion1btn = 0;
                   						     }
                   					else if (portion2btn)
                   						    {
                   						          PORTION2_Button_unselect();
                   						          PORTION3_Button_select();
                   						         downbutton = 0;
                   						         portion2btn = 0;
                   						      }


                   					else if (portion3btn)
                   					         {
                   						             PORTION3_Button_unselect();
                   						          PORTION1_Button_select();
                   					                    downbutton = 0;
                   					       			   portion3btn = 0;
                   					       	   }

                   					else
                   					{

                   						PORTION1_Button_select();
                   						PORTION3_Button_unselect();
                   						PORTION2_Button_unselect();
                   						downbutton = 0;
                   					}
                   			      }
                   		 else if (back)
                   		     {
                   			       page3menu = 1;
                   			       portionpager3 = 0;
                   			       back = 0;

                   		        }

                   			else if (enter)
                                      {
                        	              if (portion1btn)
                        	       	          {
                        	            	  portionpager3=0;
                        	            	  portionpager31=1;
                        	            	  enter=0;
                        	       	          }

                        	                else if (portion2btn)
                        	       	       	  {
                        	                	 portionpager3=0;
                        	                   	  portionpager32=1;
                        	                	    	  enter=0;
     	                        	       	          }

                        	                else if (portion3btn)
                        	                   {
                        	                	 portionpager3=0;
                        	                	   portionpager33=1;
                        	                       	  enter=0;
                        	    	       	          }
                       	                    else;

                         }
                   		  }
                   	  }

			    else if (portionpager31)
			                    {
			                      PortionPage31();
			                       while (portionpager31)
			                       {
                                       t();

			                      		  }
			                      	  }
			    else if (portionpager311)
			    			                    {
			    			                      PortionPage311();
			    			                       while (portionpager311)
			    			                       {
			                                          t1();

			   			                      		  }
			   			                      	  }
              else if (portionpager312)
              {
                PortionPage312();
                 while (portionpager312)
                 {
                      t2();
                		  }
                	  }
//////////////////////////////////////////////////////
			  else if (portionpager32)
              {
                PortionPage32();
                 while (portionpager32)
                 {
                      t();

                		  }
                	  }
else if (portionpager321)
			                    {
			                      PortionPage321();
			                       while (portionpager321)
			                       {
                                     t1();

			                      		  }
			                      	  }
else if (portionpager322)
{
PortionPage322();
while (portionpager322)
{
   t2();
		  }
	  }

			   ////////////////////////////////////
			    else if (portionpager33)
                {
                  PortionPage33();
                   while (portionpager33)
                   {
                       t();

                  		  }
                  	  }
else if (portionpager331)
			                    {
			                      PortionPage331();
			                       while (portionpager331)
			                       {
                                      t1();

			                      		  }
			                      	  }
else if (portionpager332)
{
PortionPage332();
 while (portionpager332)
 {
      t2();
		  }
	  }
 ///////////////////////////for recipe 4
else if (portionpager4)
                   	  {
                   		  PortionPageR4();
                   		  while (portionpager4)
                   		  {
                   			HAL_Delay(200);
                   			if (downbutton)
                   			      {
                   				HAL_Delay (200);
                   					if (portion1btn)
                   						    {
                   						         PORTION1_Button_unselect();
                   						         PORTION2_Button_select();
                   						         downbutton = 0;
                   						         portion1btn = 0;
                   						     }
                   					else if (portion2btn)
                   						    {
                   						          PORTION2_Button_unselect();
                   						          PORTION3_Button_select();
                   						         downbutton = 0;
                   						         portion2btn = 0;
                   						      }


                   					else if (portion3btn)
                   					         {
                   						             PORTION3_Button_unselect();
                   						          PORTION1_Button_select();
                   					                    downbutton = 0;
                   					       			   portion3btn = 0;
                   					       	   }

                   					else
                   					{

                   						PORTION1_Button_select();
                   						PORTION3_Button_unselect();
                   						PORTION2_Button_unselect();
                   						downbutton = 0;
                   					}
                   			      }
                   		 else if (back)
                   		     {
                   			       page3menu = 1;
                   			       portionpager4 = 0;
                   			       back = 0;

                   		        }

                   			else if (enter)
                                      {
                        	              if (portion1btn)
                        	       	          {
                        	            	  portionpager4=0;
                        	            	  portionpager41=1;
                        	            	  enter=0;
                        	       	          }

                        	                else if (portion2btn)
                        	       	       	  {
                        	                	 portionpager4=0;
                        	                   	  portionpager42=1;
                        	                	    	  enter=0;
     	                        	       	          }

                        	                else if (portion3btn)
                        	                   {
                        	                	 portionpager4=0;
                        	                	   portionpager43=1;
                        	                       	  enter=0;
                        	    	       	          }
                       	                    else;

                         }
                   		  }
                   	  }

			    else if (portionpager41)
			                    {
			                      PortionPage41();
			                       while (portionpager41)
			                       {
                                       t();

			                      		  }
			                      	  }
			    else if (portionpager411)
			    			                    {
			    			                      PortionPage411();
			    			                       while (portionpager411)
			    			                       {
			                                          t1();

			   			                      		  }
			   			                      	  }
              else if (portionpager412)
              {
                PortionPage412();
                 while (portionpager412)
                 {
                      t2();
                		  }
                	  }
//////////////////////////////////////////////////////
			  else if (portionpager42)
              {
                PortionPage42();
                 while (portionpager42)
                 {
                      t();

                		  }
                	  }
else if (portionpager421)
			                    {
			                      PortionPage421();
			                       while (portionpager421)
			                       {
                                     t1();

			                      		  }
			                      	  }
else if (portionpager422)
{
PortionPage422();
while (portionpager422)
{
   t2();
		  }
	  }

			   ////////////////////////////////////
			    else if (portionpager43)
                {
                  PortionPage43();
                   while (portionpager43)
                   {
                       t();

                  		  }
                  	  }
else if (portionpager431)
			                    {
			                      PortionPage431();
			                       while (portionpager431)
			                       {
                                      t1();

			                      		  }
			                      	  }
else if (portionpager432)
{
PortionPage432();
 while (portionpager432)
 {
      t2();
		  }
	  }
	  ///for recipe 5
else if (portionpager5)
                   	  {
                   		  PortionPageR5();
                   		  while (portionpager5)
                   		  {
                   			HAL_Delay(200);
                   			if (downbutton)
                   			      {
                   				HAL_Delay (200);
                   					if (portion1btn)
                   						    {
                   						         PORTION1_Button_unselect();
                   						         PORTION2_Button_select();
                   						         downbutton = 0;
                   						         portion1btn = 0;
                   						     }
                   					else if (portion2btn)
                   						    {
                   						          PORTION2_Button_unselect();
                   						          PORTION3_Button_select();
                   						         downbutton = 0;
                   						         portion2btn = 0;
                   						      }


                   					else if (portion3btn)
                   					         {
                   						             PORTION3_Button_unselect();
                   						          PORTION1_Button_select();
                   					                    downbutton = 0;
                   					       			   portion3btn = 0;
                   					       	   }

                   					else
                   					{

                   						PORTION1_Button_select();
                   						PORTION3_Button_unselect();
                   						PORTION2_Button_unselect();
                   						downbutton = 0;
                   					}
                   			      }
                   		 else if (back)
                   		     {
                   			       page3menu = 1;
                   			       portionpager5 = 0;
                   			       back = 0;

                   		        }

                   			else if (enter)
                                      {
                        	              if (portion1btn)
                        	       	          {
                        	            	  portionpager5=0;
                        	            	  portionpager51=1;
                        	            	  enter=0;
                        	       	          }

                        	                else if (portion2btn)
                        	       	       	  {
                        	                	 portionpager5=0;
                        	                   	  portionpager52=1;
                        	                	    	  enter=0;
     	                        	       	          }

                        	                else if (portion3btn)
                        	                   {
                        	                	 portionpager5=0;
                        	                	   portionpager53=1;
                        	                       	  enter=0;
                        	    	       	          }
                       	                    else;

                         }
                   		  }
                   	  }

			    else if (portionpager51)
			                    {
			                      PortionPage51();
			                       while (portionpager51)
			                       {
                                       t();

			                      		  }
			                      	  }
			    else if (portionpager511)
			    			                    {
			    			                      PortionPage511();
			    			                       while (portionpager511)
			    			                       {
			                                          t1();

			   			                      		  }
			   			                      	  }
              else if (portionpager512)
              {
                PortionPage512();
                 while (portionpager512)
                 {
                      t2();
                		  }
                	  }
//////////////////////////////////////////////////////
			  else if (portionpager52)
              {
                PortionPage52();
                 while (portionpager52)
                 {
                      t();

                		  }
                	  }
else if (portionpager521)
			                    {
			                      PortionPage521();
			                       while (portionpager521)
			                       {
                                     t1();

			                      		  }
			                      	  }
else if (portionpager522)
{
PortionPage522();
while (portionpager522)
{
   t2();
		  }
	  }

			   ////////////////////////////////////
			    else if (portionpager53)
                {
                  PortionPage53();
                   while (portionpager53)
                   {
                       t();

                  		  }
                  	  }
else if (portionpager531)
			                    {
			                      PortionPage531();
			                       while (portionpager531)
			                       {
                                      t1();

			                      		  }
			                      	  }
else if (portionpager532)
{
PortionPage532();
 while (portionpager532)
 {
      t2();
		  }
	  }
//////////////for setting menu////
			    else  if (page4menu)
                    	  {
                    		  Page4Menu();
                    		  while (page4menu)
                    		  {
                    			  HAL_Delay (200);
                    			if (downbutton)

                    		      {
                    				    HAL_Delay (200);
                    				      if (recipesetting)
                    				         {
                    				       	    PREHEATING_SETTING_SELECT();
                    				       	      RECIPE_SETTING_UNSELECT();
                    				       	     downbutton = 0;
                    				              recipesetting = 0;
                    				       						     }
                    				      else if (preheatingsetting)
                    				       						    {
                    				       						         PREHEATING_SETTING_UNSELECT();
                    				       						         SLEEPTIMER_SELECT();
                    				       						         downbutton = 0;
                    				       						         preheatingsetting = 0;
                    				       						      }


                    				      else if (sleeptimer)
                    				       					         {
                    				       					       	       SLEEPTIMER_UNSELECT();
                    				       					       	 RECIPE_SETTING_SELECT();
                    				       					       		   downbutton = 0;
                    				       					       		   sleeptimer = 0;
                    				       					       	   }

                    				       	else{

                    				       	 RECIPE_SETTING_SELECT();
                    				       	 downbutton = 0;
                    				       	 SLEEPTIMER_UNSELECT();
                    				       	}
                    		      }
                    			else if (back)
                    			                 {

                    				  page2menu = 1;  //modify rcounterbtn to page name which you make for rcounter setting
                    		       		     page4menu = 0;
                    						 back = 0;

                    			                 }

                    			else if (enter){

					                   if (recipesetting)
					        		   			  {
					        		   				  recipesettingpage = 1;
					        		   				  page4menu = 0;
					        		   				  enter = 0;
					        		   				  recipesetting = 0;
					        		   			  }
					        		   else if (preheatingsetting)
					        		   			  {
					        		   				  preheatingsettingpage = 1;
					        		   				  page4menu = 0;
					        		   				  enter = 0;
					        		   				  preheatingsetting = 0;
					        		   			  }
					        		   else if (sleeptimer)
					        		  		  {
					        		  			    sleeptimerpage = 1;
					        		  			    page4menu = 0;
					        		  			    enter = 0;
					        		  		        sleeptimer = 0;
					        		  		    }



					        		   else ;
					        	   }

                    		  }
                    	  }
			    /////////for manual///////
                else if (page5menu)
                    		 	  {
                    		             Page5Menu();
                    		                while (page5menu)
                    		                     {
                    		                	HAL_Delay (200);

                    		                	if (downbutton)
                    		                	{
                                				    HAL_Delay (200);
                                				      if (settemp)
                                				         {
                                				    	         MANUALSTART_SELECT();
                                				       	         SETTEMP_UNSELECT();
                                				       	         downbutton = 0;
                                				                   settemp = 0;
                                				       						     }
                                				      else if (manualstart)
                                				                 {
                                				    	  SETTEMP_SELECT();
                                  				                 MANUALSTART_UNSELECT();
                                  				       			   downbutton = 0;
                                  				       			   manualstart = 0;
                                   				                  }


                                				      else
                                				      {

                   				                   SETTEMP_SELECT();
                   				                   MANUALSTART_UNSELECT();
                   				                   downbutton = 0;


                                				      }


                    		                     }
                    		                	  else if(back)
                    		                	          {
                    		                	       		page5menu=0;
                    		                		 		page2menu=1;
                     	                       		 		back=0;
         		                	              	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, 0);
                    		                	                       	}
                    		                	else if (enter)
                    		                	{
                    		                		HAL_Delay (200);
                    		                		if(settemp)
                    		                		   {
                    		                			if(downbutton)
                    		                				{
                    		                				 tempreture=tempreture - 1;
                    		                				downbutton=0;
                    		                		        	}
                    		                			 else if (upbutton)
		                                                      {
                    		                				 tempreture= tempreture + 1;
                    		                				    upbutton=0;
		                                                      }
                    		                			 else;
                    		                		   }


                    		                	else if (manualstart)
                    		                		{
                                                           if(T < tempreture)
                                                           {
                                                        	   HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, 1);
                                                        	   					  enter = 0;
                                                        	  }
                                                           else if(T > tempreture)
                                                           {
                                                        	   HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, 0);
                                                        	   					  enter = 0;
                                                           }
                                                           else;
                    		                		}

                                                           else;

                    		                	}
                    		                     }
                    		 	  }
			    ///forrecipesettingpage///

                else  if (recipesettingpage)
                         {
                            RECIPE_SETTING_PAGE();
                              while (recipesettingpage)
                                    {
                            	  HAL_Delay (200);
                                  if (downbutton)

                                     {
                                         HAL_Delay (200);
                                      if (recipe1)
                                           {
                                    	     RECIPE2_SELECT();
                                    	     RECIPE1_UNSELECT();
                                             downbutton = 0;
                                    		 recipe1 = 0;
                                            }
                                      else if (recipe2)
                                        {
		       						         RECIPE2_UNSELECT();
		       						         RECIPE3_SELECT();
		       						         downbutton = 0;
		       						         recipe2 = 0;
		       						      }


                                     else if (recipe3)
                                    	{
		       					       	       RECIPE3_UNSELECT();
		       					       	 RECIPE1_SELECT();
		       					       		   downbutton = 0;
		       					       		   recipe3 = 0;
		       					       	   }

                                       	else{

                                   	 RECIPE1_SELECT();
                                   	 RECIPE2_UNSELECT();
                                   	RECIPE3_UNSELECT();
                                   	downbutton = 0;


                                       	}
                                     }
                                  else if (back)
                                                {
                                                page4menu= 1;
                                                  recipesetting = 0;
                                             	 back = 0;
                                                   }
                               else if (enter)

                                               	    {
                                               if (recipe1)
                                                   {
                                            	        recipe1setting=1;
                                            	        recipesetting=0;
                                            	        enter = 0;
                					        		   	recipe1= 0;
                					        		   }
                					         else if (recipe2)
                					        		 {
                					                    recipe2setting = 1;
                					        		   	recipesetting = 0;
                					        		   	  enter = 0;
                					        		   	 recipe2 = 0;
                					        		   			  }
                					        		   else if (recipe3)
                					        		  		  {
                					        		  			    recipe3setting = 1;
                					        		  			    recipesetting = 0;
                					        		  			    enter = 0;
                					        		  		        recipe3 = 0;
                					        		  		    }




                					        		   else;
                					        	   }

                                    		  }
                         }



////for recipe1setting//////////////
                else   if (recipe1setting)
                {
			    	RECIPE1SETTING();

			    	while(recipe1setting)
			    	{
			    		HAL_Delay (200);
                        if (downbutton)

                           {
                               HAL_Delay (200);
                               if (portion1btn)
                                 {
                            	   PORTION1_Button_unselect();
                            	   PORTION2_Button_select();
                                   downbutton = 0;
                          		 recipe1 = 0;
                                  }
                            else if (portion2btn)
                              {
                            	PORTION1_Button_unselect();
     						         PORTION3_Button_select();
     						         downbutton = 0;
     						         recipe2 = 0;
     						      }


                           else if (portion3btn)
                          	{
                        	   PORTION3_Button_unselect();
                        	   PORTION1_Button_select();

     					       		   downbutton = 0;
     					       		   recipe3 = 0;
     					       	   }

                          				       	else
                          				       	{

                                                PORTION1_Button_select();

                                                 downbutton = 0;


                          				       	}
                           }
                     else if (enter)
                          	    {
                                     if (portion1btn)
                                         {
                                    	 HAL_Delay (200);
                                    	 //RxVal1 =Flash_Read_NuM(0);

			                    		  time = RxVal;
			                    		  ST7735_WriteString(10, 20, "press 'up'/'down' button for changes", Font_7x10, GREEN, BLACK);
			                    		  ST7735_WriteInt(30, 20,time , Font_11x18, GREEN, BLACK);
                                         if(upbutton)
	                    					{
	                    					   time= time + 1;
	                    					    upbutton=0;
	                    					     ST7735_WriteInt(50, 20,time , Font_11x18, GREEN, BLACK);

	                    					          }
	                    				 else if(downbutton)
	                    					 {
	                    					   	 time= time - 1;
	                    					     downbutton=0;
	                    					     ST7735_WriteInt(50, 20,time , Font_11x18, GREEN, BLACK);
	                    					   }
	                    				 else if (enter)
		                    					  {
		                    		 //        Flash_Write_NUM(0x08005C10, number);   //change the memory address first
		                    					    enter=0;
		                    					 recipe1setting=1;
		                    					  }
		                    				 else ;
                                    }


      					         else if (portion2btn)
      					        		 {
      					        	      HAL_Delay (200);
      					        	    //RxVal2 =Flash_Read_NuM(0);

			                    		  time = RxVal;

			                    		  ST7735_WriteString(10, 20, "press 'up'/'down' button for changes", Font_7x10, GREEN, BLACK);
			                    		  ST7735_WriteInt(30, 20,time , Font_11x18, GREEN, BLACK);
                                        if(upbutton)
	                    					{
	                    					   time= time + 1;
	                    					    upbutton=0;
	                    					     ST7735_WriteInt(50, 20,time , Font_11x18, GREEN, BLACK);

	                    					          }
	                    				 else if(downbutton)
	                    					 {
	                    					   	 time= time - 1;
	                    					     downbutton=0;
	                    					     ST7735_WriteInt(50, 20,time , Font_11x18, GREEN, BLACK);
	                    					   }
	                    				 else if (back)
	                    				            {
	                    				      	         page4menu= 1;
	                    				     	     recipesetting = 0;
	                    				       		 back = 0;

	                    				       		  }

	                    				 else if (enter)
		                    					  {
		                    		 //        Flash_Write_NUM(0x08005C10, number);   //change the memory address first
		                    					    enter=0;
		                    					 recipe1setting=1;
		                    					  }
	                    				 else;
      					        		   			  }
      					        		   else if (portion3btn)
      					        		  		  {
      		      					        	      HAL_Delay (200);
      		      					        	  //RxVal3 =Flash_Read_NuM(0);

      					                    		  time = RxVal;
      					                    		  ST7735_WriteString(10, 20, "press 'up'/'down' button for changes", Font_7x10, GREEN, BLACK);
      					                    		  ST7735_WriteInt(30, 20,time , Font_11x18, GREEN, BLACK);
      		                                        if(upbutton)
      			                    					{
      			                    					   time= time + 1;
      			                    					    upbutton=0;
      			                    					     ST7735_WriteInt(50, 20,time , Font_11x18, GREEN, BLACK);

      			                    					          }
      			                    				 else if(downbutton)
      			                    					 {
      			                    					   	 time= time - 1;
      			                    					     downbutton=0;
      			                    					     ST7735_WriteInt(50, 20,time , Font_11x18, GREEN, BLACK);
      			                    					   }
      			                    				 else if (enter)
      				                    					  {
      				                    		 //        Flash_Write_NUM(0x08005C10, number);   //change the memory address first
      				                    					    enter=0;
      				                    					 recipe1setting=1;
      				                    					  }
      			                    				 else;

      					        		  		    }




      					        		   else ;
      					        	   }
                    }
                    }
  else if (recipe2setting)
                {
                	RECIPE2SETTING();

	          while(recipe2setting)
	                {
	        	  HAL_Delay (200);
                        if (downbutton)

                              {
               HAL_Delay (200);
               if (portion1btn)
                 {
            	   PORTION1_Button_unselect();
            	   PORTION2_Button_select();
                   downbutton = 0;
          		 recipe1 = 0;
                  }
            else if (portion2btn)
              {
            	PORTION2_Button_unselect();
				         PORTION3_Button_select();
				         downbutton = 0;
				         recipe2 = 0;
				      }


           else if (portion3btn)
          	{
        	   PORTION3_Button_unselect();
        	   PORTION1_Button_select();

			       		   downbutton = 0;
			       		   recipe3 = 0;
			       	   }

          				       	else;
           }
                        else if (back){
                        	recipesetting=1;
                        	recipe2setting=0;
                        	back=0;
                        }
     else if (enter)
          	    {
                     if (portion1btn)
                         {
                    	 HAL_Delay (200);
                    	 //RxVal4 =Flash_Read_NuM(0);

                		  time = RxVal;
                		  ST7735_WriteString(10, 20, "press 'up'/'down' button for changes", Font_7x10, GREEN, BLACK);
        		  ST7735_WriteInt(30, 20,time , Font_11x18, GREEN, BLACK);
                         if(upbutton)
        					{
        					   time= time + 1;
        					    upbutton=0;
        					     ST7735_WriteInt(50, 20,time , Font_11x18, GREEN, BLACK);

        					          }
        				 else if(downbutton)
        					 {
        					   	 time= time - 1;
        					     downbutton=0;
        					     ST7735_WriteInt(50, 20,time , Font_11x18, GREEN, BLACK);
        					   }
        				 else if (enter)
            					  {
            		 //        Flash_Write_NUM(0x08005C10, number);   //change the memory address first
            					    enter=0;
            					 recipe2setting=1;
            					  }
        				 else if (back){
        				                         	recipesetting=1;

        				                         	back=0;
        				                         }
            				 else ;
                    }


			         else if (portion2btn)
			        		 {
			        	      HAL_Delay (200);
			        	      //RxVal =Flash_Read_NuM(0);

                		  time = RxVal;
                		  ST7735_WriteString(10, 20, "press 'up'/'down' button for changes", Font_7x10, GREEN, BLACK);
                		  ST7735_WriteInt(30, 20,time , Font_11x18, GREEN, BLACK);
                        if(upbutton)
        					{
        					   time= time + 1;
        					    upbutton=0;
        					     ST7735_WriteInt(50, 20,time , Font_11x18, GREEN, BLACK);

        					          }
        				 else if(downbutton)
        					 {
        					   	 time= time - 1;
        					     downbutton=0;
        					     ST7735_WriteInt(50, 20,time , Font_11x18, GREEN, BLACK);
        					   }
        				 else if (enter)
            					  {
            		 //        Flash_Write_NUM(0x08005C10, number);   //change the memory address first
            					    enter=0;
            					 recipe2setting=1;
            					  }
        				 else;
			        		   			  }
			        		   else if (portion3btn)
			        		  		  {
    					        	      HAL_Delay (200);
    					        	      //RxVal6 =Flash_Read_NuM(0);

			                    		  time= RxVal;
			                    		  ST7735_WriteString(10, 20, "press 'up'/'down' button for changes", Font_7x10, GREEN, BLACK);
			                    		  ST7735_WriteInt(30, 20,time , Font_11x18, GREEN, BLACK);
                                      if(upbutton)
	                    					{
	                    					   time= time + 1;
	                    					    upbutton=0;
	                    					     ST7735_WriteInt(50, 20,time , Font_11x18, GREEN, BLACK);

	                    					          }
	                    				 else if(downbutton)
	                    					 {
	                    					   	 time= time - 1;
	                    					     downbutton=0;
	                    					     ST7735_WriteInt(50, 20,time , Font_11x18, GREEN, BLACK);
	                    					   }
	                    				 else if (enter)
		                    					  {
		                    		 //        Flash_Write_NUM(0x08005C10, number);   //change the memory address first
		                    					    enter=0;
		                    					 recipe2setting=1;
		                    					  }
	                    				 else;

			        		  		    }




			        		   else ;
			        	   }
    }
    }
                else  if (recipe3setting)
                {
	              	RECIPE3SETTING();

		while(recipe3setting)
		{
			HAL_Delay (200);
			if (back){
			                        	recipesetting=1;
			                        	recipe2setting=0;
			                        	back=0;
			                        }
			else    if (downbutton)

	           {
	               HAL_Delay (200);
	               if (portion1btn)
	                 {
	            	   PORTION1_Button_unselect();
	            	   PORTION2_Button_select();
	                   downbutton = 0;
	          		 recipe1 = 0;
	                  }
	            else if (portion2btn)
	              {
	            	PORTION1_Button_unselect();
					         PORTION3_Button_select();
					         downbutton = 0;
					         recipe2 = 0;
					      }


	           else if (portion3btn)
	          	{
	        	   PORTION3_Button_unselect();


				       		   downbutton = 0;
				       		   recipe3 = 0;
				       	   }

	          				       	else;
	           }
	     else if (enter)
	          	    {
	                     if (portion1btn)
	                         {
	                    	 HAL_Delay (200);
	                    	 //RxVal7 =Flash_Read_NuM(0);

        	               		  time = RxVal;
	                		  ST7735_WriteString(10, 20, "press 'up'/'down' button for changes", Font_7x10, GREEN, BLACK);
	                		  ST7735_WriteInt(30, 20,time , Font_11x18, GREEN, BLACK);
	                         if(upbutton)
	        					{
	        					   time= time + 1;
	        					    upbutton=0;
	        					     ST7735_WriteInt(50, 20,time , Font_11x18, GREEN, BLACK);

	        					          }
	        				 else if(downbutton)
	        					 {
	        					   	 time= time - 1;
	        					     downbutton=0;
	        					     ST7735_WriteInt(50, 20,time , Font_11x18, GREEN, BLACK);
	        					   }
	        				 else if (enter)
	            					  {
	            		 //        Flash_Write_NUM(0x08005C10, number);   //change the memory address first
	            					    enter=0;
	            					 recipe3setting=1;
	            					  }
	            				 else ;
	                    }


				         else if (portion2btn)
				        		 {
				        	      HAL_Delay (200);
				        	      //RxVal8 =Flash_Read_NuM(0);

	                		  time = RxVal;
	                		  ST7735_WriteString(10, 20, "press 'up'/'down' button for changes", Font_7x10, GREEN, BLACK);
	                		  ST7735_WriteInt(30, 20,time, Font_11x18, GREEN, BLACK);
	                        if(upbutton)
	        					{
	        					   time= time + 1;
	        					    upbutton=0;
	        					     ST7735_WriteInt(50, 20,time , Font_11x18, GREEN, BLACK);

	        					          }
	        				 else if(downbutton)
	        					 {
	        					   	 time= time - 1;
	        					     downbutton=0;
	        					     ST7735_WriteInt(50, 20,time , Font_11x18, GREEN, BLACK);
	        					   }
	        				 else if (enter)
	            					  {
	            		 //        Flash_Write_NUM(0x08005C10, number);   //change the memory address first
	            					    enter=0;
	            					 recipe3setting=1;
	            					  }
	        				 else;
				        		   			  }
				        		   else if (portion3btn)
				        		  		  {
	    					        	      HAL_Delay (200);
	    					        	      //RxVal9 =Flash_Read_NuM(0);

				                    		  time = RxVal;
				                    		  ST7735_WriteString(10, 20, "press 'up'/'down' button for changes", Font_7x10, GREEN, BLACK);
				                    		  ST7735_WriteInt(30, 20,time , Font_11x18, GREEN, BLACK);
	                                      if(upbutton)
		                    					{
		                    					   time= time + 1;
		                    					    upbutton=0;
		                    					     ST7735_WriteInt(50, 20,time, Font_11x18, GREEN, BLACK);

		                    					          }
		                    				 else if(downbutton)
		                    					 {
		                    					   	 time= time - 1;
		                    					     downbutton=0;
		                    					     ST7735_WriteInt(50, 20,time , Font_11x18, GREEN, BLACK);
		                    					   }
		                    				 else if (enter)
			                    					  {
			                    		 //        Flash_Write_NUM(0x08005C10, number);   //change the memory address first
			                    					    enter=0;
			                    					 recipe3setting=1;
			                    					  }
		                    				 else;

				        		  		    }

				        		   else ;
				        	   }}}

else if (preheatingsettingpage)
	  {
		  Preheatingsettingpage();
		  while (preheatingsettingpage)
		  {
			  HAL_Delay (200);
			  if (back){
			                          	recipesetting=1;
			                          	recipe2setting=0;
			                          	back=0;
			                          }
		  else if (downbutton)
			      {
					  HAL_Delay (200);
					if (preheatingsetting)
						    {
						         PREHEATING_SETTING_UNSELECT();

						         downbutton = 0;
						         preheatingsettingpage = 0;
						     }

					    else;
			          }

		 else if (enter)
		      {

						   if (preheatingsetting)
						        {
							        ST7735_WriteString(10, 20, "press 'up'/'down' button for changes", Font_7x10, GREEN, BLACK);
							        HAL_Delay (200);
							        heatingvalue = RxVal;
							        sprintf(hv,"%u    ",heatingvalue);
							       // ST7735_WriteInt(30, 20,hv , Font_11x18, GREEN, BLACK);

							      if(upbutton)
							        {
							          heatingvalue= heatingvalue + 1;
							          upbutton=0;
							          ST7735_WriteInt(50, 20,time , Font_11x18, GREEN, BLACK);

							          }
							         else if(downbutton)
							         {
							         	     heatingvalue= heatingvalue - 1;
							         	      downbutton=0;
							         	   ST7735_WriteInt(50, 20,time , Font_11x18, GREEN, BLACK);
							         	   }
							         	else if (enter)
							         	   {
							         	   //        Flash_Write_NUM(0x08005C10, number);   //change the memory address first
							         	       enter=0;
							         	        recipe3setting=1;
							         	       }
							         	   else ;
						            enter = 0;
						            recipe1 = 0;
						          }

						        		  else ;
						        	   }
						           }
						        }






}



///next work to numberised Rdxval
////provide address according to bluepill use
////check how much flash memory is used or avialable
///preheating setting page
// add counter and counter setting page




////////////////////////////////////////////////raw material//////////////////////////////////////////////////////////////////////////








