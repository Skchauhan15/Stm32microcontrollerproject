/*
 * TFT_MENU.h
 *
 *
 */

#ifndef INC_TFT_MENU_H_
#define INC_TFT_MENU_H_

void HomeMenu (void);
void testMenu (void);
void Page2Menu (void);
void Page3Menu (void);
void Page4Menu (void);
void Page5Menu (void);
void PortionPageR1 (void);
void Menu_Handler (void);
void PortionPageR2 (void);
void PortionPageR3 (void);
void PortionPage11 (void);
void PortionPage12 (void);
void PortionPage13 (void);
void PortionPage21 (void);
void PortionPage22 (void);
void PortionPage23 (void);
void PortionPage31 (void);
void PortionPage32 (void);
void PortionPage33 (void);
void RECIPE_SETTING_PAGE (void);
void RECIPE1SETTING (void);
void RECIPE2SETTING (void);
void RECIPE3SETTING (void);
void Preheatingsettingpage (void);
#endif /* INC_TFT_MENU_H_ */
